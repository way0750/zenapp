(function() {
  function simpleCheck (obj) {
    console.log(Object.keys(obj).join(',  '));
  }
  return {
    events: {
      'app.activated':'doSomething'
    },

    doSomething: function() {
      alert('see me?');
    }
  };

}());
